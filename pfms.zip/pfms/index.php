<?php
	include_once 'header.php';
?>


<div id = "HeadLine">
	<h1><strong> Welcome </strong></h1> 
	<h2> <strong> to</strong></h2> 
	<h1>Our Farm !!!</h1>
</div>



<?php
	include_once 'footer.php';
?>